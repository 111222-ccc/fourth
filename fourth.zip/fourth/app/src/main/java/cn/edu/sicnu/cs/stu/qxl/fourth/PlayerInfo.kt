package cn.edu.sicnu.cs.stu.fourth

object PlayerInfo {
    var name: String = ""
    var gender: String = ""
    var phone: String = ""
    var highScore: Int = 0
}
