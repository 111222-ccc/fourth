package cn.edu.sicnu.cs.stu.qxl.fourth.model

class CardMatchingGame(val count: Int) {
    var score = 0
        private set

    private val cards: MutableList<Card>

    val MISMATCH_PENALTY = 2
    val MATCH_BONUS = 4
    val COST_TO_CHOOSE = 1

    init {
        val deck = Deck()
        cards = mutableListOf()
        for (i in 1..count) {
            val card: Card? = deck.drawRandomCard()
            if (card != null) {
                cards.add(card)
            }
        }
    }

    fun reset() {
        score = 0
        val deck = Deck()
        cards.clear()
        for (i in 1..count) {
            val card: Card? = deck.drawRandomCard()
            if (card != null) {
                cards.add(card)
            }
        }
    }

    fun cardAtIndex(index: Int): Card {
        return cards[index]
    }

    fun chooseCardAtIndex(index: Int) {
        val card = cardAtIndex(index)
        if (card.isMatched) return

        if (card.isChosen) {
            card.isChosen = false
            return
        }

        // 每次选牌都扣成本
        score -= COST_TO_CHOOSE
        val chosenCards = cards.filter { it.isChosen && !it.isMatched }
        card.isChosen = true

        when (chosenCards.size) {
            0 -> {
                // 当前0张翻开，现在翻开这一张
            }
            1 -> {
                // 已经有一张翻开，现在两张
                val otherCard = chosenCards[0]
                val matchScore = card.match(arrayOf(otherCard))
                if (matchScore > 0) {
                    score += matchScore * MATCH_BONUS
                    card.isMatched = true
                    otherCard.isMatched = true
                } else {
                    score -= MISMATCH_PENALTY
                }
            }
            else -> {
                // 已经翻开2张，全部盖回去，再翻开新牌
                for (c in chosenCards) {
                    c.isChosen = false
                }
            }
        }
    }
}
