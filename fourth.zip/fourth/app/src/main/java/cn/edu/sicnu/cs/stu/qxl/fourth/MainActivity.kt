package cn.edu.sicnu.cs.stu.qxl.fourth

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import cn.edu.sicnu.cs.stu.fourth.PlayerInfo

class MainActivity : AppCompatActivity() {

    private lateinit var tvName: TextView
    private lateinit var tvGender: TextView
    private lateinit var tvPhone: TextView
    private lateinit var tvHighScore: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        tvName = findViewById(R.id.tv_name)
        tvGender = findViewById(R.id.tv_gender)
        tvPhone = findViewById(R.id.tv_phone)
        tvHighScore = findViewById(R.id.tv_highscore)

        val btnEdit: Button = findViewById(R.id.btn_edit)
        val btnGame: Button = findViewById(R.id.btn_game)

        btnEdit.setOnClickListener {
            val intent = Intent(this, EditInfoActivity::class.java)
            startActivity(intent)
        }

        btnGame.setOnClickListener {
            val intent = Intent(this, CardGameActivity::class.java)
            startActivity(intent)
        }
    }

    override fun onResume() {
        super.onResume()
        refreshInfoUi()
    }

    private fun refreshInfoUi() {
        tvName.text = getString(R.string.tv_name, PlayerInfo.name)
        tvGender.text = getString(R.string.tv_gender, PlayerInfo.gender)
        tvPhone.text = getString(R.string.tv_phone, PlayerInfo.phone)
        tvHighScore.text = getString(R.string.tv_highscore, PlayerInfo.highScore)
    }
}
