package cn.edu.sicnu.cs.stu.qxl.fourth

import android.graphics.Color
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import cn.edu.sicnu.cs.stu.qxl.fourth.model.CardMatchingGame

class CardGameActivity : AppCompatActivity() {
    private val game = CardMatchingGame(16)
    private lateinit var scoreTv: TextView
    private lateinit var btnReset: Button
    private var btns: List<Button> = emptyList()
    private val handler = Handler(Looper.getMainLooper())
    private var isWaiting = false // 是否正在等待延时翻面，防止疯狂点击

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_card_game)

        scoreTv = findViewById(R.id.scoreTv)
        btnReset = findViewById(R.id.btnReset)

        btns = listOf(
            findViewById(R.id.button),
            findViewById(R.id.button1),
            findViewById(R.id.button2),
            findViewById(R.id.button3),
            findViewById(R.id.button4),
            findViewById(R.id.button5),
            findViewById(R.id.button6),
            findViewById(R.id.button7),
            findViewById(R.id.button8),
            findViewById(R.id.button9),
            findViewById(R.id.button10),
            findViewById(R.id.button11),
            findViewById(R.id.button12),
            findViewById(R.id.button13),
            findViewById(R.id.button14),
            findViewById(R.id.button15)
        )

        for (i in btns.indices) {
            val idx = i
            btns[idx].setOnClickListener {
                if(isWaiting) return@setOnClickListener
                game.chooseCardAtIndex(idx)
                // 获取现在翻开且未匹配的卡牌
                val openCards = (0 until 16).map { game.cardAtIndex(it) }.filter { it.isChosen && !it.isMatched }
                updateUI()
                if(openCards.size == 2){
                    val c1 = openCards[0]
                    val c2 = openCards[1]
                    if(c1.match(arrayOf(c2)) <=0 ){
                        // 两张不匹配，延时700ms盖回去
                        isWaiting = true
                        handler.postDelayed({
                            c1.isChosen = false
                            c2.isChosen = false
                            updateUI()
                            isWaiting = false
                        },700)
                    }
                }
            }
        }

        btnReset.setOnClickListener {
            game.reset()
            isWaiting = false
            handler.removeCallbacksAndMessages(null)
            updateUI()
        }
        updateUI()
    }

    private fun updateUI() {
        scoreTv.text = getString(R.string.score_text, game.score)
        for (i in btns.indices) {
            val card = game.cardAtIndex(i)
            val btn = btns[i]
            when {
                card.isMatched -> {
                    btn.text = card.toString()
                    btn.setBackgroundColor(Color.WHITE)
                    btn.isEnabled = false
                }
                card.isChosen -> {
                    btn.text = card.toString()
                    btn.setBackgroundColor(Color.WHITE)
                    btn.isEnabled = true
                }
                else -> {
                    btn.text = ""
                    btn.setBackgroundResource(R.drawable.background)
                    btn.isEnabled = true
                }
            }
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        handler.removeCallbacksAndMessages(null)
    }
}
